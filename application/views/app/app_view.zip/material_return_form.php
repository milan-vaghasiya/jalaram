<?php $this->load->view('app/includes/header'); ?>
	<!-- Header -->
	<header class="header">
		<div class="main-bar">
			<div class="container">
				<div class="header-content">
					<div class="left-content">
						<a href="javascript:void(0);" class="back-btn">
							<svg height="512" viewBox="0 0 486.65 486.65" width="512"><path d="m202.114 444.648c-8.01-.114-15.65-3.388-21.257-9.11l-171.875-171.572c-11.907-11.81-11.986-31.037-.176-42.945.058-.059.117-.118.176-.176l171.876-171.571c12.738-10.909 31.908-9.426 42.817 3.313 9.736 11.369 9.736 28.136 0 39.504l-150.315 150.315 151.833 150.315c11.774 11.844 11.774 30.973 0 42.817-6.045 6.184-14.439 9.498-23.079 9.11z"></path><path d="m456.283 272.773h-425.133c-16.771 0-30.367-13.596-30.367-30.367s13.596-30.367 30.367-30.367h425.133c16.771 0 30.367 13.596 30.367 30.367s-13.596 30.367-30.367 30.367z"></path>
							</svg>
						</a>
						<h5 class="title mb-0 text-nowrap">Material Return</h5>
					</div>
					<div class="mid-content">
					</div>
					<div class="right-content">
					</div>
				</div>
			</div>
		</div>
	</header>
	<!-- Header -->
    <div class="container pb">
        <div class="content-body">	
            <form id="returnMaterial">

                <input type="hidden" name="issue_id" value="<?=(isset($dataRow->id) && !empty($dataRow->id) ? $dataRow->id : "") ?>">
                <input type="hidden" name="issue_number" value="<?=(isset($dataRow->issue_number) && !empty($dataRow->issue_number) ? $dataRow->issue_number : "") ?>">
                <input type="hidden" name="batch_no" value="<?=(isset($dataRow->batch_no) && !empty($dataRow->batch_no) ? $dataRow->batch_no : "") ?>">
                <input type="hidden" name="issue_qty" value="<?=(isset($dataRow->issue_qty) && !empty($dataRow->issue_qty) ? abs($dataRow->issue_qty) : "") ?>">
                <input type="hidden" name="return_qty" value="<?=(isset($dataRow->return_qty) && !empty($dataRow->return_qty) ? abs($dataRow->return_qty) : "") ?>">
                <input type="hidden" name="item_id" value="<?=(isset($dataRow->item_id) && !empty($dataRow->item_id) ? $dataRow->item_id : "") ?>">

                <div class="row">
                    <div class="col">
                        <div class="mb-3">
                            <label class="form-label" for="trans_date">Trans Date</label>
                            <input type="date" name="trans_date" class="form-control" value="<?=date("Y-m-d")?>" />
                        </div>
                    </div>

                    <div class="col">
                        <div class="mb-3">
                            <label class="form-label" for="used_qty">For Reuse Qty</label>
                            <input type="text" name="used_qty" class="form-control req" value="" />
                        </div>
                    </div>
                </div>

                <div class="row">
                    <div class="col">
                        <div class="mb-3">
                            <label class="form-label" for="fresh_qty">Fresh Qty</label>
                            <input type="text" name="fresh_qty" class="form-control req" value="" />
                        </div>
                    </div>

                    <div class="col">
                        <div class="mb-3">
                            <label class="form-label" for="missed_qty">Missed Qty</label>
                            <input type="text" name="missed_qty" class="form-control req" value="" />
                        </div>
                    </div>
                </div>

                <div class="row">
                    <div class="col">
                        <div class="mb-3">
                            <label class="form-label" for="broken_qty">Broken Qty</label>
                            <input type="text" name="broken_qty" class="form-control req" value="" />
                        </div>
                    </div>

                    <div class="col">
                        <div class="mb-3">
                            <label class="form-label" for="scrap_qty">Scrap Qty</label>
                            <input type="text" name="scrap_qty" class="form-control req" value="" />
                        </div>
                    </div>
                </div>

                <div class="row">
                    <div class="col">
                        <div class="mb-3">
                            <label class="form-label" for="remark">Remark</label>
                            <input type="text" name="remark" class="form-control" value="" />
                        </div>
                    </div>
                </div>

                <div class="error genral_error"></div>

            </form>
        </div>
        <div class="footer fixed">
            <div class="container">
                <?php
                    $param = "{'formId':'returnMaterial','fnsave':'saveReturnReq','controller':'requisition','res_function':'responseFunction'}";
                ?>
                <a href="javascript:void(0)" class="btn btn-primary btn-block" onclick="store(<?=$param?>)">Save</a>
            </div>
        </div>
    </div>
<?php $this->load->view('app/includes/footer'); ?>
<script>
$(document).ready(function(){
    setPlaceHolder();
    $(".select2").select2();
});

function responseFunction(data,formId){
    if(data.status==1){
       $('#'+formId)[0].reset();
       Swal.fire({
            title: "Success",
            text: data.message,
            icon: "success",
            showCancelButton: false,
            confirmButtonColor: "#3085d6",
            cancelButtonColor: "#d33",
            confirmButtonText: "Ok!"
        }).then((result) => {
            window.location = base_url + 'app/requisition/materialReturn';
        });
    }else{
        if(typeof data.message === "object"){
            $(".error").html("");
            $.each( data.message, function( key, value ) {$("."+key).html(value);});
        }else{
            Swal.fire({ icon: 'error', title: data.message });
        }			
    }	
   
}
</script>