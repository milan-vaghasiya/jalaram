<?php $this->load->view('app/includes/header'); ?>
	<!-- Header -->
	<header class="header">
		<div class="main-bar">
			<div class="container">
				<div class="header-content">
					<div class="left-content">
						<a href="javascript:void(0);" class="back-btn">
							<svg height="512" viewBox="0 0 486.65 486.65" width="512"><path d="m202.114 444.648c-8.01-.114-15.65-3.388-21.257-9.11l-171.875-171.572c-11.907-11.81-11.986-31.037-.176-42.945.058-.059.117-.118.176-.176l171.876-171.571c12.738-10.909 31.908-9.426 42.817 3.313 9.736 11.369 9.736 28.136 0 39.504l-150.315 150.315 151.833 150.315c11.774 11.844 11.774 30.973 0 42.817-6.045 6.184-14.439 9.498-23.079 9.11z"></path><path d="m456.283 272.773h-425.133c-16.771 0-30.367-13.596-30.367-30.367s13.596-30.367 30.367-30.367h425.133c16.771 0 30.367 13.596 30.367 30.367s-13.596 30.367-30.367 30.367z"></path>
							</svg>
						</a>
						<h5 class="title mb-0 text-nowrap"><?=(!empty($dataRow->id) ? 'Update': "Add") ?> </h5>
					</div>
					<div class="mid-content">
                    <h5 class="title mb-0 text-nowrap"><?=(!empty($dataRow->log_number) ? $dataRow->log_number : $log_number)?> </h5
					</div>
					<div class="right-content">
					</div>
				</div>
			</div>
		</div>
	</header>
	<!-- Header -->
    <div class="container pb">
        <div class="product-area">	
            <form id="requisitionForm">
                
                <input type="hidden" name="id" value="<?=(isset($dataRow->id) && !empty($dataRow->id) ? $dataRow->id : "") ?>">
                <div class="row">
                    <input type="hidden" name="log_number" id="log_number" class="form-control req" value="<?=(!empty($dataRow->log_number) ? $dataRow->log_number : $log_number)?>"  />
                    <input type="hidden" name="log_no" id="log_no" value="<?=(!empty($dataRow->log_no)) ? $dataRow->log_no : $log_no?>" />
                    <div class="col">
                        <div class="mb-3">
                            <label class="form-label" for="item_id">Item</label>
                            <select name="item_id" id="item_id" class="form-control select2 req">
                                <option value="">Select Item</option>
                                <?php
                                    if(isset($itemData) && !empty(isset($itemData))){
                                        foreach ($itemData as $value) {
                                            $selected = "";
                                            if(isset($dataRow->item_id) && !empty($dataRow->item_id))
                                                if($dataRow->item_id == $value->id)
                                                    $selected = "selected";
                                            echo "<option value='".$value->id."' ".$selected.">".$value->item_name."</option>";
                                        }
                                    }
                                ?>
                            </select>
                            <div class="error item_err"></div>
                        </div>
                    </div>
                </div>
                <div class="row">
                    <div class="col">
                        <div class="mb-3">
                            <label class="form-label" for="mc_id">Machine</label>
                            <select name="mc_id" id="mc_id" class="form-control select2">
                                <option value="">Select Machine</option>
                                <?php
                                    if(isset($mcData) && !empty(isset($mcData))){
                                        foreach ($mcData as $value) {
                                            $selected = "";
                                            if(isset($dataRow->mc_id) && !empty($dataRow->mc_id))
                                                if($dataRow->mc_id == $value->id)
                                                    $selected = "selected";
                                            echo "<option value='".$value->id."' ".$selected.">".$value->item_name."</option>";
                                        }
                                    }
                                ?>
                            </select>
                        </div>
                    </div>
                </div>
                <div class="row">
                    <div class="col">
                        <div class="mb-3">
                            <label class="form-label" for="fg_id">Finish Good</label>
                            <select name="fg_id" id="fg_id" class="form-control select2">
                                <option value="">Select Finish Good</option>
                                <?php
                                    if(isset($fgData) && !empty(isset($fgData))){
                                        foreach ($fgData as $value) {
                                            $selected = "";
                                            if(isset($dataRow->fg_id) && !empty($dataRow->fg_id))
                                                if($dataRow->fg_id == $value->id)
                                                    $selected = "selected";
                                            echo "<option value='".$value->id."' ".$selected.">".$value->item_name."</option>";
                                        }
                                    }
                                ?>
                            </select>
                        </div>
                    </div>
                </div>
                <div class="row">
                    <div class="col">
                        <div class="mb-3">
                            <label class="form-label" for="req_qty">Req. Qty</label>
                            <input type="text" name="req_qty" class="form-control req" value="<?=(isset($dataRow->req_qty) && !empty($dataRow->req_qty) ? $dataRow->req_qty : "") ?>" />
                            <div class="error qty_err"></div>
                        </div>
                    </div>
                    <div class="col">
                        <div class="mb-3">
                            <label class="form-label" for="urgency">Urgency</label>
                            <select name="urgency" id="urgency" class="form-control single-select select2">
                                <option value="">Select Urgency</option>
                                <option value="0" <?=(isset($dataRow->urgency) && !empty($dataRow->urgency) ? (($dataRow->urgency == 0) ? "selected" : "") : "") ?>>Low</option>
                                <option value="1" <?=(isset($dataRow->urgency) && !empty($dataRow->urgency) ? (($dataRow->urgency == 1) ? "selected" : "") : "") ?>>Medium</option>
                                <option value="2" <?=(isset($dataRow->urgency) && !empty($dataRow->urgency) ? (($dataRow->urgency == 2) ? "selected" : "") : "") ?>>High</option>
                            </select>
                        </div>
                    </div>
                </div>
                <div class="row">
                    <div class="col">
                        <div class="mb-3">
                        <label class="form-label" for="remark">Remark</label>
                        <input type="text" name="remark" class="form-control" value="<?=(isset($dataRow->remark) && !empty($dataRow->remark) ? $dataRow->remark : "") ?>" />
                    </div>
                </div>

            </form>
        </div>
        <div class="footer fixed">
            <div class="container">
                <?php
                    $param = "{'formId':'requisitionForm','fnsave':'save','controller':'requisition','res_function':'responseFunction'}";
                ?>
                <a href="javascript:void(0)" class="btn btn-primary btn-block" onclick="store(<?=$param?>)">Save</a>
            </div>
        </div>
    </div>
<?php $this->load->view('app/includes/footer'); ?>
<script>
$(document).ready(function(){
    setPlaceHolder();
    $(".select2").select2();
});

function responseFunction(data,formId){
    if(data.status==1){
       $('#'+formId)[0].reset();
       Swal.fire({
            title: "Success",
            text: data.message,
            icon: "success",
            showCancelButton: false,
            confirmButtonColor: "#3085d6",
            cancelButtonColor: "#d33",
            confirmButtonText: "Ok!"
        }).then((result) => {
            window.location = base_url + 'app/requisition';
        });
    }else{
        if(typeof data.message === "object"){
            $(".error").html("");
            $.each( data.message, function( key, value ) {$("."+key).html(value);});
        }else{
            Swal.fire({ icon: 'error', title: data.message });
        }			
    }	
   
}
</script>