<div class="menubar-area style-5 footer-fixed">
	<!-- <div class="toolbar-inner menubar-nav">
		<a href="<?=base_url("app/dashboard")?>" class="nav-link <?=($this->data['headData']->controller == 'app/dashboard')?'active':''?>">
			<svg xmlns="http://www.w3.org/2000/svg" viewBox="0 0 512 512"><path d="M506.555 208.064L263.859 30.367a13.3 13.3 0 0 0-15.716 0L5.445 208.064c-5.928 4.341-7.216 12.665-2.875 18.593a13.31 13.31 0 0 0 18.593 2.875L256 57.588l234.837 171.943c2.368 1.735 5.12 2.57 7.848 2.57 4.096 0 8.138-1.885 10.744-5.445 4.342-5.927 3.054-14.251-2.874-18.592zm-64.309 24.479c-7.346 0-13.303 5.956-13.303 13.303v211.749H322.521V342.009c0-36.68-29.842-66.52-66.52-66.52s-66.52 29.842-66.52 66.52v115.587H83.058V245.847c0-7.347-5.957-13.303-13.303-13.303s-13.303 5.956-13.303 13.303V470.9c0 7.347 5.957 13.303 13.303 13.303h133.029c6.996 0 12.721-5.405 13.251-12.267.032-.311.052-.651.052-1.036V342.01c0-22.009 17.905-39.914 39.914-39.914s39.914 17.906 39.914 39.914V470.9c0 .383.02.717.052 1.024.524 6.867 6.251 12.279 13.251 12.279h133.029c7.347 0 13.303-5.956 13.303-13.303V245.847c-.001-7.348-5.957-13.304-13.304-13.304z"/></svg>
			<span>Home</span>
		</a>
		<a href="<?=base_url("app/lead/crmDesk")?>" class="nav-link <?=($this->data['headData']->controller == 'app/lead')?'active':''?>">	
			<svg fill="none" height="24" viewBox="0 0 24 24" width="24" xmlns="http://www.w3.org/2000/svg"><g fill="rgb(0,0,0)"><path d="m12 12.75c-3.17 0-5.75-2.58-5.75-5.75s2.58-5.75 5.75-5.75 5.75 2.58 5.75 5.75-2.58 5.75-5.75 5.75zm0-10c-2.34 0-4.25 1.91-4.25 4.25s1.91 4.25 4.25 4.25 4.25-1.91 4.25-4.25-1.91-4.25-4.25-4.25z"/><path d="m20.5901 22.75c-.41 0-.75-.34-.75-.75 0-3.45-3.5199-6.25-7.8399-6.25-4.32005 0-7.84004 2.8-7.84004 6.25 0 .41-.34.75-.75.75s-.75-.34-.75-.75c0-4.27 4.18999-7.75 9.34004-7.75 5.15 0 9.3399 3.48 9.3399 7.75 0 .41-.34.75-.75.75z"/></g></svg>
			<span>Crm Desk</span>
		</a>
	</div>
	-->
	<div class="toolbar-inner menubar-nav">
		<a href="<?=base_url("app/dashboard")?>" class="nav-link <?=($this->data['headData']->appMenu == 'app/dashboard')?'active':''?>">
			<div class="shape">
				<i class="fa-solid fa-house"></i>
				<div class="inner-shape"></div>
			</div>
			<span>Home</span>
		</a>
		<a href="<?=base_url("app/requisition")?>" class="nav-link <?=($this->data['headData']->appMenu == 'app/requisition')?'active':''?>">
			<div class="shape">
				<i class=" fas fa-warehouse"></i>
				<div class="inner-shape"></div>
			</div>
			<span>Requisition</span>
		</a>
		<a href="<?=base_url("app/issueRequisition")?>" class="nav-link <?=($this->data['headData']->appMenu == 'app/issueRequisition')?'active':''?>">
			<div class="shape">
				<i class="fas fa-paper-plane"></i>
				<div class="inner-shape"></div>
			</div>
			<span>Material Issue</span>
		</a>
		<a href="<?=base_url("app/requisition/materialReturn")?>" class="nav-link <?=($this->data['headData']->appMenu == 'app/requisition/materialReturn')?'active':''?>">
			<div class="shape">
				<i class="fas fa-undo-alt"></i>
				<div class="inner-shape"></div>
			</div>
			<span>Material Return</span>
		</a>
		<!-- <a href="<?=base_url("app/employee")?>" class="nav-link <?=($this->data['headData']->appMenu == 'app/employee')?'active':''?>">
			<div class="shape">
				<i class="fas fa-user-cog"></i>
				<div class="inner-shape"></div>
			</div>
			<span>Profile</span>
		</a> -->
	</div>
</div>