<!-- PWA Offcanvas -->
<div class="offcanvas offcanvas-bottom pwa-offcanvas">
	<div class="container">
		<div class="offcanvas-body small">
			<img class="logo" src="assets/images/icon.png" alt="">
			<h6 class="title font-w600">Comet Poly Plast Pvt.Ltd | Flow Forever</h6>
			<p class="pwa-text">Install Comet Poly Plast Mobile App</p>
			<button type="button" class="btn btn-sm btn-primary pwa-btn">Install</button>
			<button type="button" class="btn btn-sm pwa-close btn-secondary ms-2 text-white">Close</button>
		</div>
	</div>
</div>
<div class="offcanvas-backdrop pwa-backdrop"></div>
<!-- PWA Offcanvas End -->