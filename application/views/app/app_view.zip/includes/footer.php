
		<?php $this->load->view('app/includes/footerfiles');?>
		<?php $this->load->view('app/includes/modal');?>
	</body>
</html>