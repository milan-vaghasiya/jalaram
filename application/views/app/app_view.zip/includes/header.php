<!DOCTYPE html>
<html lang="en">
<?php $this->load->view('app/includes/headerfiles'); ?>
<body data-theme-color="color-teal">
<div class="page-wraper">
	<!-- Preloader -->
	<div id="preloader">
		<div class="loader">
			<span></span>
			<span></span>
			<span></span>
			<span></span>
			<span></span>
		</div>
	</div>