<?php $this->load->view('app/includes/header'); ?>
	<!-- Header -->
	<header class="header">
		<div class="main-bar">
			<div class="container">
				<div class="header-content">
					<div class="left-content">
						<a href="javascript:void(0);" class="back-btn">
							<svg height="512" viewBox="0 0 486.65 486.65" width="512"><path d="m202.114 444.648c-8.01-.114-15.65-3.388-21.257-9.11l-171.875-171.572c-11.907-11.81-11.986-31.037-.176-42.945.058-.059.117-.118.176-.176l171.876-171.571c12.738-10.909 31.908-9.426 42.817 3.313 9.736 11.369 9.736 28.136 0 39.504l-150.315 150.315 151.833 150.315c11.774 11.844 11.774 30.973 0 42.817-6.045 6.184-14.439 9.498-23.079 9.11z"></path><path d="m456.283 272.773h-425.133c-16.771 0-30.367-13.596-30.367-30.367s13.596-30.367 30.367-30.367h425.133c16.771 0 30.367 13.596 30.367 30.367s-13.596 30.367-30.367 30.367z"></path>
							</svg>
						</a>
						<h5 class="title mb-0 text-nowrap">Material Issue -  <?=$dataRow->log_number?></h5>
					</div>
					<div class="mid-content">
					</div>
					<div class="right-content">
					</div>
				</div>
			</div>
		</div>
	</header>
	<!-- Header -->
    <div class="container pb">
        <div class="content-body">	
            <form id="requisitionForm">
                
                <input type="hidden" name="log_id" value="<?=(isset($dataRow->id) && !empty($dataRow->id) ? $dataRow->id : "") ?>">
                <input type="hidden" name="is_return" value="<?=(isset($dataRow->is_return) && !empty($dataRow->is_return) ? $dataRow->is_return : "") ?>">
                <input type="hidden" name="log_number" id="log_number" value="<?=(isset($dataRow->log_number) && !empty($dataRow->log_number) ? $dataRow->log_number : "") ?>">
                <input type="hidden" name="req_qty" value="<?=(isset($dataRow->req_qty) && !empty($dataRow->req_qty) ? ($dataRow->req_qty - $dataRow->issue_qty) : "") ?>">
                <div class="table-responsive">
                    <table class="table table-bordered">
                        <tbody>
                            <tr>
                                <th colspan="3" class="bg-light">
                                    <?=$dataRow->item_name?>
                                    <input type="hidden" name="item_id" value="<?=(isset($dataRow->item_id) && !empty($dataRow->item_id) ? $dataRow->item_id : "") ?>">
                                </th>
                            </tr>
                            <tr class="bg-light text-center">
                                <th>Req Qty</th>
                                <th>Issue Qty</th>
                                <th>Pending Qty</th>
                            </tr>
                            <tr class=" text-center">
                                <td><?=$dataRow->req_qty?></td>
                                <td><?=$dataRow->issue_qty?></td>
                                <td><?=($dataRow->req_qty - $dataRow->issue_qty)?></td>
                            </tr>
                        </tbody>
                    </table>
                </div>
                <h6>Batch Data : </h6>
                <div class="error table_err"></div> 
                <?php
                if(isset($batchData) && !empty($batchData)){
                    $i=1;
                    foreach($batchData as $row){
                        ?>
                        <div class="card order-box" >
                            <div class="card-body">
                                <a href="javascript:void(0)">
                                    <div class="order-content mb-0">
                                        <div class="right-content">
                                            <div class="title mb-0"><?=$row->location?></div>
                                            <ul>
                                                <li>
                                                    <p class="order-name"><?=$row->batch_no?> | <?=$row->stock_type?></p>
                                                    <span class="order-quantity"><?=floatval($row->qty)?></span>
                                                </li>
                                            </ul>
                                        </div>
                                    </div>
                                    <input type="number" name="batch_qty[]" class="form-control batchQty floatOnly" data-stock_qty="<?=floatval($row->qty)?>" min="0" value="" data-row_id="<?=$i?>" />
                                    <div class="error batch_qty_<?=$i?>"></div>
                                    <input type="hidden" name="batch_no[]" id="batch_number_<?=$i?>" value="<?=$row->batch_no?>" />
                                    <input type="hidden" name="location_id[]" id="location_<?=$i?>" value="<?=$row->location_id?>" />
                                    <input type="hidden" name="stock_type[]" id="stock_type_<?=$i?>" value="<?=$row->stock_type?>" />
                                </a>
                            </div>
                        </div>
                <?php $i++; } } ?>
            </form>
        </div>
        <div class="footer fixed">
            <div class="container">
                <?php
                    $param = "{'formId':'requisitionForm','fnsave':'saveIssueRequisition','controller':'issueRequisition','res_function':'responseFunction'}";
                ?>
                <a href="javascript:void(0)" class="btn btn-primary btn-block" onclick="store(<?=$param?>)">Save</a>
            </div>
        </div>
    </div>
<?php $this->load->view('app/includes/footer'); ?>
<script>
$(document).ready(function(){
    setPlaceHolder();
    $(".select2").select2();
    $(document).on('input',".batchQty",function(){	
		var id = $(this).data('row_id');
		var cl_stock = $(this).data('stock_qty');
		var batchQty = $(this).val();
		$(".batch_qty"+id).html("");
		$(".qty").html();
		if(parseFloat(batchQty) > parseFloat(cl_stock)){
			$(".batch_qty"+id).html("Stock not avalible.");
			$(this).val("");
		}
	});
});

function responseFunction(data,formId){
    if(data.status==1){
       $('#'+formId)[0].reset();
       Swal.fire({
            title: "Success",
            text: data.message,
            icon: "success",
            showCancelButton: false,
            confirmButtonColor: "#3085d6",
            cancelButtonColor: "#d33",
            confirmButtonText: "Ok!"
        }).then((result) => {
            window.location = base_url + 'app/issueRequisition';
        });
    }else{
        if(typeof data.message === "object"){
            $(".error").html("");
            $.each( data.message, function( key, value ) {$("."+key).html(value);});
        }else{
            Swal.fire({ icon: 'error', title: data.message });
        }			
    }	
   
}
</script>