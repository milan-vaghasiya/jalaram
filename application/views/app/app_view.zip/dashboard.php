<?php $this->load->view('app/includes/header'); ?>
<?php $this->load->view('app/includes/topbar'); ?>
	<!-- Page Content -->
    <div class="page-content bottom-content">
        <div class="container">
		</div>
    </div>    
    <!-- Page Content End-->

<?php $this->load->view('app/includes/bottom_menu'); ?>
<?php $this->load->view('app/includes/footer'); ?>

<script src="<?=base_url('assets/app/index.js')?>"></script>